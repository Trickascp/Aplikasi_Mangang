import React, { Component } from 'react';
import { Route, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Cookies from 'universal-cookie';

import { keepLogin, cookieChecked, onUserLogin, loadOfCart } from './actions';
import './App.css';
import HeaderKu from './components/HeaderKu';
import HomeKu from './components/HomeKu';
import LoginKu from './components/LoginKu';
import RegisterKu from './components/RegisterKu';
import VerifiyWaitingKu from './components/VerifyWaitingKu';
import VerifiedKu from './components/VerifiedKu';
import ProductDetailKu from './components/ProductDetailKu';
import KeranjangKu from './components/KeranjangKu';
import ConfirmPaymentKu from './components/ConfirmPaymentKu';
import HomeAdmin from './components/admin/HomeAdmin';
import InputProductAdmin from './components/admin/InputProductAdmin';
import VerifyOrderAdmin from './components/admin/VerifyOrderAdmin';
import HistoryBelanjaKu from './components/HistoryBelanjaKu';
import CariBukuKu from './components/CariBukuKu';
import CartAgent from './components/agent/CartAgent';
import InputConsument from './components/agent/InputConsument';
import ManageAgent from './components/admin/ManageAgent';
import HomeAgent from './components/agent/HomeAgent';
import OrderAgent from './components/agent/OrderAgent';
import ConfirmOrderAgent from './components/agent/ConfirmOrderAgent';
import ProdukNegara from './components/ProdukNegara';
import ReportsAdmin from './components/admin/ReportsAdmin';
import CategoryAdmin from './components/admin/CategoryAdmin';
import CountryAdmins from './components/admin/CountryAdmins';
import Agentsubscribe from './components/Agentsubscribe';
import KonfirmasiPembayaran from './components/KonfirmasiPembayaran';
import registerAgentData from './components/registerAgentData';
import pricing from './components/admin/pricing';
import CartCustomer from './components/agent/CartCustomer';
import historyAdmin from './components/admin/historyAdmin';
import DetailOrderMonth from './components/admin/detaliorderthismonth';
import orderdetail from './components/agent/orderdetail';
import underConstruction from './components/underConstruction';
import ordercustomer from './components/agent/ordercustomer';
import addphotos from './components/admin/addphotos';
import ReactLoading from 'react-loading';
import searchProduk from './components/searchProduk';
import NegaraAll from './components/fitur/negaraAll';
import forgetuser from './components/forgetuser';
import reset from './components/reset';
import editProduk from './components/admin/editProduk';
import addCarousell from './components/admin/addCarousell';
import invoiceCustomer from './components/agent/invoiceCustomer';
import landingPage from './components/landingPage';
const cookies = new Cookies();

class App extends Component {
  
  componentDidMount() {
      const username = cookies.get('myPengguna');
      //console.log(username);
      if(username !== undefined){
          this.props.keepLogin(username);
          this.props.loadOfCart({username});
      } else {
        this.props.cookieChecked();
      }
  }
 underConstraction =()=>{
   var comingsoon = 'no';
   if(comingsoon == 'yes'){
     if(this.props.user.role != 'Admin' && this.props.user.role !='User'){
       
      return<Route exact path="/" component={underConstruction} />
     }else{
      
      return  <div>
      <HeaderKu />
      <Route exact path="/" component={landingPage} />
    </div>
     }
    
   }else{
     
    return(<div>
       <HeaderKu />
    <Route exact path="/" component={landingPage} />
    </div>)
   }
 }
  render() {
    if(this.props.cookie){ 
      return (
        <div className="App">
          
          
         
          {/* <Route exact path="/" component={HomeKu} /> */}
          {this.underConstraction()}
          <Route path="/login" component={LoginKu} />
          <Route path="/register" component={RegisterKu} />
          <Route path="/forget" component={forgetuser}/>
          <Route path="/reset" component={reset}/>
          <div className=" myBody  bg-white" >
          {/* style={{borderRadius: "5px"}} */}
          
          <Route path="/home" component={HomeKu} />
            <Route path="/product" component={searchProduk} />
            <Route path="/allcountry" component={NegaraAll}/>
           
            <Route path="/registeragentdata" component={registerAgentData} />
            <Route path="/verify" component={VerifiyWaitingKu} />
            <Route path="/verified" component={VerifiedKu} />
            <Route path="/productdetail/:id" component={ProductDetailKu} />
            <Route path="/cart" component={KeranjangKu} />
            <Route path="/confirmpayment" component={ConfirmPaymentKu} />
            <Route path="/historytrx" component={HistoryBelanjaKu} />
            <Route path="/searchbook" component={CariBukuKu} />
            <Route path="/admin/home" component={HomeAdmin} />
            <Route path="/admin/inputproduct" component={InputProductAdmin} />
            <Route path="/admin/editproduct" component={editProduk} />
            <Route path="/admin/verifyorder" component={VerifyOrderAdmin} />
            <Route path="/admin/manageagent" component={ManageAgent} />
            <Route path="/admin/report" component={ReportsAdmin} />
            <Route path="/admin/history" component={historyAdmin} />
            <Route path="/admin/pricing" component={pricing} />
            <Route path="/admin/category" component={CategoryAdmin} />
            <Route path="/admin/country" component={CountryAdmins} />
            <Route path="/admin/carousell" component={addCarousell} />
            <Route path="/admin/reportmonth" component={DetailOrderMonth} />
            <Route path="/admin/addphotos" component={addphotos} />
            <Route path="/agent/home" component={HomeAgent} />
            <Route path="/agent/cart" component={CartAgent} />
            <Route path="/agent/cartcustomer" component={CartCustomer} />
            <Route path="/agent/ordercustomer" component={ordercustomer} />
            <Route path="/agent/inputConsument" component={InputConsument} />
            <Route path="/agent/order" component={OrderAgent} />
            <Route path="/agent/orderdetail" component={orderdetail} />
            <Route path="/agent/confirmpayment" component={ConfirmOrderAgent} />
            <Route path="/invoicecustomer" component={invoiceCustomer} />
            <Route path="/negara" component={ProdukNegara} />
            <Route path="/cartorderagent" component={Agentsubscribe} />
            <Route path="/konfirmasipembayaran" component={KonfirmasiPembayaran} />
          </div>

        </div>
      );
    }
    return (  
      <div className="App">
        <HeaderKu />
        <div className="row loading" style={{borderRadius: "5px"}}>
            <ReactLoading type='cylon' color="#065286" height={100} width={190} />
        </div>
      </div>
    );
  }
}



const mapStateToProps = (state) => {
  return {  cookie: state.auth.cookie,
            user: state.auth,
            cart: state.loadOfCart }
}
export default withRouter(connect(mapStateToProps, {keepLogin, cookieChecked, onUserLogin, loadOfCart})(App));
